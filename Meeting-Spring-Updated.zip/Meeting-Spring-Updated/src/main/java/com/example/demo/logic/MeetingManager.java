/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.demo.logic;

import com.example.demo.persistent.Meeting;
import com.example.demo.persistent.Persistent;
import java.util.List;
/**
 *
 * @author moorthy
 */
public class MeetingManager {

    //add meeting
    public boolean addMeeting(String title, String date, String timing, String teammembers) {
        if(Persistent.getInstance().addMeeting(title, date, timing, teammembers)){
            return true;
        }
        return false;
    }
    
    //get meeting
    public List getMeeting()
    {
        return Persistent.getInstance().getMeeting();
    }
}
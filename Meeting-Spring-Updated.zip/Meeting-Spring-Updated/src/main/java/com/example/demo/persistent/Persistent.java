/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.demo.persistent;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author moorthy
 */
public class Persistent {

    //list
    private ArrayList<Meeting> meetings = new ArrayList<>();

    //instance-Persistent
    private static Persistent instance = new Persistent();

    //adding meeting
    public boolean addMeeting(String title, String date, String timing, String teammembers) {
        try{
            Meeting meetingModel = new Meeting();
            meetingModel.setTitle(title);
            meetingModel.setDate(date);
            meetingModel.setTime(timing);
            meetingModel.setUser(teammembers);
            meetings.add(meetingModel);
            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }
    
    //getting meeting
    public List getMeeting()
    {
        int i;
        List<Meeting> returnMeetings = new ArrayList();
        for(i = meetings.size() - 1; i >= 0; i--)
        {
            returnMeetings.add(meetings.get(i));
        }
        return returnMeetings;
    }
    //Instance
    public static Persistent getInstance() {
        return instance;
    }

    //object
    public void persist(Object o) {
    }
}
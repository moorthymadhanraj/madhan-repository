package com.example.demo.persistent;

import javax.validation.constraints.NotEmpty;

public class Meeting {
	@NotEmpty(message = "Title is required")
	private String title;

	@NotEmpty(message = "Date is required")
	private String date;

	
	private String time;

	@NotEmpty(message = "Please select team-member")
	private String user;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

}
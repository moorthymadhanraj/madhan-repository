package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.example.demo.logic.MeetingManager;
import com.example.demo.persistent.Meeting;

// Controller Should have all HTTP related codes and ModeAndView related codes.
@Controller
public class MeetingController {

    List<Meeting> al = new ArrayList();

    // RequestMapping with Model & View - Calling meeting template(form) to fill
    // details about meeting.
    @RequestMapping("/")
    public String meeting(Model model) {
        model.addAttribute("meeting", new Meeting());
        return "meeting";
    }

    // RequestMapping with Model & View - Calling meeting template(form) to fill
    // details about meeting.
    @RequestMapping(value = "/meetings", method = RequestMethod.POST)
    public ModelAndView meetings(@Valid Meeting meeting, BindingResult bindingResult) {

        // Obj from Manager class
        MeetingManager meetingManager = new MeetingManager();
        ModelAndView modelAndView = new ModelAndView();

        //validating
        if (!bindingResult.hasErrors()) {
            meetingManager.addMeeting(meeting.getTitle(), meeting.getDate(), meeting.getTime(), meeting.getUser());
            al = meetingManager.getMeeting();
            modelAndView.setViewName("calender");
            System.out.println("running");
        } else {
            modelAndView.addObject("meeting", meeting);
            modelAndView.setViewName("meeting");
        }
        return modelAndView;
    }

    @RequestMapping(value = "/calenders", produces = {MediaType.APPLICATION_JSON_VALUE}, method = RequestMethod.GET)
    public ResponseEntity<List<Meeting>> getCompanyList() {

        return new ResponseEntity<List<Meeting>>(al, HttpStatus.OK);
    }

    @RequestMapping(value = "/calender", method = RequestMethod.GET)
    public ModelAndView calender() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("calender");
        return modelAndView;
    }
}